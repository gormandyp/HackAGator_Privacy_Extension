
const TRACKERS = [
  { domain: "doubleclick.net", company: "Google", category: "Advertising", country: "US" },
  { domain: "google-analytics.com", company: "Google", category: "Analytics", country: "US" },
  { domain: "googletagmanager.com", company: "Google", category: "Analytics", country: "US" },
  { domain: "connect.facebook.net", company: "Meta", category: "Advertising", country: "US" },
  { domain: "facebook.net", company: "Meta", category: "Advertising", country: "US" },
  { domain: "amazon-adsystem.com", company: "Amazon", category: "Advertising", country: "US" },
  { domain: "criteo.com", company: "Criteo", category: "Advertising", country: "FR" },
  { domain: "scorecardresearch.com", company: "Comscore", category: "Analytics", country: "US" },
  { domain: "hotjar.com", company: "Hotjar", category: "Session recording", country: "MT" },
  { domain: "rlcdn.com", company: "LiveRamp", category: "Data broker", country: "US" },
  { domain: "ct.pinterest.com", company: "Pinterest", category: "Advertising", country: "US" },
  { domain: "mc.yandex.ru", company: "Yandex", category: "Analytics", country: "RU" },
  { domain: "hm.baidu.com", company: "Baidu", category: "Analytics", country: "CN" }
];

const tabSites = new Map();

function matchingTracker(hostname) {
  return TRACKERS.find(t =>
    hostname === t.domain || hostname.endsWith("." + t.domain)
  );
}

function cleanDomain(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return null;
  }
}

async function saveSites() {
  const sites = [...tabSites.values()];
  await chrome.storage.local.set({
    privacData: { sample: false, sites }
  });
}

// Start a fresh record when a tab navigates to a new website.
chrome.webNavigation.onCommitted.addListener(details => {
  if (details.frameId !== 0) return;

  const domain = cleanDomain(details.url);
  if (!domain) return;

  tabSites.set(details.tabId, {
    domain,
    lastVisit: new Date().toISOString(),
    cookieChoice: "none",
    policy: { sells: null, shares: null, source: null },
    trackers: []
  });

  saveSites();
});

// Detect requests to known tracking domains.
chrome.webRequest.onBeforeRequest.addListener(
  details => {
    if (details.tabId < 0) return;

    const site = tabSites.get(details.tabId);
    if (!site) return;

    const hostname = cleanDomain(details.url);
    if (!hostname) return;

    const tracker = matchingTracker(hostname);
    if (!tracker) return;

    // Don't count a site's own requests as third-party tracking.
    if (
      hostname === site.domain ||
      hostname.endsWith("." + site.domain)
    ) return;

    if (!site.trackers.some(t => t.domain === tracker.domain)) {
      site.trackers.push(tracker);
      site.lastVisit = new Date().toISOString();
      saveSites();
    }
  },
  { urls: ["<all_urls>"] }
);

// Clean up closed tabs.
chrome.tabs.onRemoved.addListener(tabId => {
  tabSites.delete(tabId);
});
